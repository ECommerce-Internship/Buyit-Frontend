import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { AuthModalProvider } from './context/AuthModalContext';
import { LandingPage } from './pages/LandingPage';

/**
 * App router. The auth screens (login / register, buyer / seller) are a single
 * <AuthModal> rendered globally by <AuthModalProvider> and opened from any CTA —
 * they are NOT separate routes in the source design. If you want dedicated
 * routes (e.g. /login, /register) the modal body can be lifted into a page.
 */
export default function App() {
  return (
    <AuthModalProvider>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<LandingPage />} />
        </Routes>
      </BrowserRouter>
    </AuthModalProvider>
  );
}
