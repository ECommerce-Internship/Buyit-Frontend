import { useState } from 'react';
import { Hoverable } from './ui/Hoverable';
import { BuyitLogo } from './ui/BuyitLogo';
import { useAuthModal } from '../context/AuthModalContext';

const navLink = (extra = {}) => ({
  textDecoration: 'none', fontSize: 14.5, fontWeight: 500,
  color: 'rgba(255,255,255,0.66)', ...extra,
}) as const;

export function Nav() {
  const { openAuth } = useAuthModal();
  const [mobileMenu, setMobileMenu] = useState(false);
  const links = [
    { href: '#features', label: 'Features' },
    { href: '#buyers',   label: 'For Buyers' },
    { href: '#sellers',  label: 'For Sellers' },
    { href: '#how',      label: 'How it works' },
    { href: '#reviews',  label: 'Reviews' },
  ];

  return (
    <nav style={{
      position: 'sticky', top: 0, zIndex: 50, backdropFilter: 'blur(14px)',
      WebkitBackdropFilter: 'blur(14px)', background: 'rgba(10,10,18,0.72)',
      borderBottom: '1px solid rgba(255,255,255,0.08)',
    }}>
      <div style={{
        maxWidth: 1200, margin: '0 auto', padding: '14px 24px', display: 'flex',
        alignItems: 'center', justifyContent: 'space-between', gap: 20,
      }}>
        <a href="#top" style={{ display: 'flex', alignItems: 'center', gap: 10, textDecoration: 'none' }}>
          <span style={{ display: 'inline-flex', filter: 'drop-shadow(0 0 12px rgba(139,92,246,0.5))' }}>
            <BuyitLogo size={30} gradientId="navBag" />
          </span>
          <span style={{ fontFamily: 'Outfit', fontWeight: 700, fontSize: 20, letterSpacing: '-0.02em', color: '#fff' }}>Buyit</span>
        </a>

        <div className="nav-links" style={{ display: 'flex', alignItems: 'center', gap: 30 }}>
          {links.map((l) => (
            <Hoverable as="a" key={l.href} href={l.href} style={navLink()} hoverStyle={{ color: '#fff' }}>
              {l.label}
            </Hoverable>
          ))}
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <Hoverable
            as="button"
            onClick={() => openAuth('login', 'buyer')}
            style={{ background: 'transparent', border: 'none', color: 'rgba(255,255,255,0.82)', fontFamily: 'inherit', fontSize: 14.5, fontWeight: 600, cursor: 'pointer', padding: '9px 8px' }}
            hoverStyle={{ color: '#fff' }}
          >
            Log in
          </Hoverable>
          <Hoverable
            as="button"
            onClick={() => openAuth('register', 'buyer')}
            style={{ fontFamily: 'inherit', fontSize: 14.5, fontWeight: 600, color: '#fff', padding: '10px 18px', border: 'none', borderRadius: 11, cursor: 'pointer', background: 'linear-gradient(120deg, #ff8a4c, #ff4d6d)', boxShadow: '0 8px 22px -8px rgba(255,77,109,0.6)', transition: 'transform .15s, box-shadow .2s' }}
            hoverStyle={{ transform: 'translateY(-1px)', boxShadow: '0 12px 30px -8px rgba(255,77,109,0.8)' }}
          >
            Get started
          </Hoverable>
          <button
            onClick={() => setMobileMenu((v) => !v)}
            className="menu-btn"
            aria-label="Open menu"
            style={{ alignItems: 'center', justifyContent: 'center', width: 40, height: 40, padding: 0, background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.14)', borderRadius: 11, color: '#fff', cursor: 'pointer' }}
          >
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M4 7h16M4 12h16M4 17h16" /></svg>
          </button>
        </div>
      </div>

      {mobileMenu && (
        <div style={{ borderTop: '1px solid rgba(255,255,255,0.08)', padding: '14px 24px', display: 'flex', flexDirection: 'column', gap: 4, background: 'rgba(10,10,18,0.96)' }}>
          {links.map((l) => (
            <a key={l.href} href={l.href} onClick={() => setMobileMenu(false)}
              style={{ textDecoration: 'none', padding: '11px 6px', fontSize: 15, fontWeight: 500, color: 'rgba(255,255,255,0.8)' }}>
              {l.label}
            </a>
          ))}
        </div>
      )}
    </nav>
  );
}
