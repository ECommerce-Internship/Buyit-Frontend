interface Props {
  size?: number;
  /** Unique gradient id — required so multiple instances don't collide. */
  gradientId: string;
}

/** The Buyit shopping-bag mark. Gradient: #8b5cf6 → #6366f1 → #22d3ee. */
export function BuyitLogo({ size = 30, gradientId }: Props) {
  return (
    <svg width={size} height={size} viewBox="0 0 120 120" fill="none" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <linearGradient id={gradientId} x1="20" y1="24" x2="100" y2="108" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#8b5cf6" />
          <stop offset="55%" stopColor="#6366f1" />
          <stop offset="100%" stopColor="#22d3ee" />
        </linearGradient>
      </defs>
      <path d="M40 50 V42 a8 8 0 0 1 16 0 V50" stroke={`url(#${gradientId})`} strokeWidth="6" strokeLinecap="round" />
      <path d="M64 50 V42 a8 8 0 0 1 16 0 V50" stroke={`url(#${gradientId})`} strokeWidth="6" strokeLinecap="round" />
      <path d="M26 48 H94 L89 100 a9 9 0 0 1 -8 8 H39 a9 9 0 0 1 -8 -8 Z" fill={`url(#${gradientId})`} />
    </svg>
  );
}
