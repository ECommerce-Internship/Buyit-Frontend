# Buyit Landing — React + TypeScript + Vite + Tailwind v4 port

A faithful, file-by-file port of the **Buyit** multi-seller marketplace landing page
(including the animated hero "delivery radar" and the full auth modal). The visuals are
**unchanged** from the design — this bundle only reorganizes the existing design into clean
React/TS files for handoff.

---

## 1. File tree

```
design_handoff_buyit/
├── index.html
├── package.json
├── tsconfig.json
├── vite.config.ts
├── README.md                         ← this file
├── reference/
│   └── Buyit Landing.reference.html  ← the original design (read-only reference)
└── src/
    ├── main.tsx                      ← entry point (createRoot)
    ├── App.tsx                       ← router + global AuthModalProvider
    ├── index.css                     ← Tailwind import, fonts, keyframes, responsive CSS
    ├── types.ts                      ← shared TS types
    ├── data/
    │   └── landing.ts                ← ALL placeholder data (stores, stats, features, …)
    ├── hooks/
    │   └── useLandingMotion.ts       ← reveal cascade + count-up + parallax
    ├── context/
    │   └── AuthModalContext.tsx      ← openAuth(mode, role) provider + modal mount
    ├── pages/
    │   └── LandingPage.tsx           ← composes every section
    └── components/
        ├── Nav.tsx
        ├── Hero.tsx
        ├── MarketplaceRadar.tsx      ← the animated hero scene (auto-rotating radar)
        ├── TrustStrip.tsx
        ├── Features.tsx
        ├── ForBuyers.tsx
        ├── ForSellers.tsx
        ├── SellerDashboard.tsx
        ├── HowItWorks.tsx
        ├── CategoriesMarquee.tsx
        ├── Testimonials.tsx
        ├── FinalCTA.tsx
        ├── Footer.tsx
        ├── AuthModal.tsx             ← login/register × buyer/seller, validation, success
        └── ui/
            ├── Hoverable.tsx         ← polymorphic element with inline hover/focus styles
            └── BuyitLogo.tsx         ← shared shopping-bag SVG mark
```

To run: `cd design_handoff_buyit && npm install && npm run dev`.

---

## 2. About the design files

The original design was authored as an interactive HTML prototype (`reference/Buyit
Landing.reference.html`). This bundle is the **production-oriented React recreation** of that
prototype. The `.reference.html` file is included only so you can diff behavior/visuals — do
not ship it.

---

## 3. Fidelity — HIGH

Pixel-accurate. Final colors, typography, spacing, gradients, shadows, and interactions are
all carried over exactly.

### Styling approach (important)
The source uses **inline styles** for every visual detail (exact px values, multi-stop
gradients, rgba shadows). To guarantee zero visual drift, this port keeps those as React
inline `style={{…}}` objects rather than rewriting them into Tailwind utility classes.
Tailwind v4 **is** installed and active (`@import "tailwindcss"` in `index.css`) and ready for
you to migrate incrementally. The only things that genuinely can't be inline live in
`index.css`: `@keyframes`, the responsive `@media` breakpoints, the marquee animation, and
input `::placeholder` colors.

Hover/focus states are reproduced exactly via the small `<Hoverable>` helper, which merges a
`hoverStyle` / `focusStyle` object on the relevant events (inline `:hover` isn't possible in
React).

---

## 4. Dependencies

Runtime packages actually imported by the code:

- **react** ^19 — used everywhere
- **react-dom** ^19 — `createRoot` in `main.tsx`
- **react-router-dom** ^7 — `BrowserRouter`/`Routes`/`Route` in `App.tsx`
- **tailwindcss** ^4 + **@tailwindcss/vite** — imported in `index.css`, plugin in `vite.config.ts`

Dev/build: `vite`, `@vitejs/plugin-react`, `typescript`, `@types/react`, `@types/react-dom`.

### Against your allowed set
Allowed: react, react-dom, react-router-dom, lucide-react, @tanstack/react-query,
react-hot-toast, recharts, tailwindcss.

- **Used:** react, react-dom, react-router-dom, tailwindcss.
- **NOT used (no install needed):** lucide-react, @tanstack/react-query, react-hot-toast, recharts.
- **Outside the set — NONE.** No extra packages are required.

### Animation / 3D / UI libraries
- **framer-motion: NOT used.** All motion is CSS `@keyframes` + a couple of small
  `setInterval`/`requestAnimationFrame` effects (`useLandingMotion.ts`, `MarketplaceRadar.tsx`,
  `Testimonials.tsx`).
- No 3D libraries, no headless-UI / Radix, no icon library — icons are inline SVGs.

#### Optional swaps (your call, not required)
- `lucide-react` could replace the inline SVG icons.
- `recharts` could replace the hand-drawn SVG charts in `SellerDashboard.tsx`.
- `@tanstack/react-query` for the real data fetches that replace the mocked arrays.
- `react-hot-toast` for submit feedback instead of the inline success state.

---

## 5. Tailwind

- **Version assumed: Tailwind v4** (CSS-first config, no `tailwind.config.js`).
- Setup: `@import "tailwindcss";` at the top of `src/index.css` + the `@tailwindcss/vite`
  plugin in `vite.config.ts`. **No PostCSS file, no `tailwind.config.js`, no custom `@theme`
  tokens, no plugins** — so there are no config conflicts to resolve.
- The design currently uses **no Tailwind utility classes** (see §3). All color/spacing values
  live inline; the token table in §8 lists them so you can lift them into a `@theme` block if
  you choose to Tailwind-ify.

---

## 6. Assets

No external images, fonts files, or icon packages are bundled. Specifically:

- **Fonts:** Google Fonts — **Outfit** (display headings) and **Plus Jakarta Sans** (body),
  loaded via `@import url(...)` in `src/index.css`.
- **Logo:** `ui/BuyitLogo.tsx` — inline SVG shopping-bag mark (gradient #8b5cf6→#6366f1→#22d3ee).
  Rendered in Nav, Footer, and AuthModal. Each instance needs a unique `gradientId` prop.
- **Icons:** all inline SVG within their components (cart, check, eye/eye-off, chevrons,
  search, menu, close, info, Google "G", Twitter/Instagram/LinkedIn, and the 8 feature icons
  in `Features.tsx`).
- **Charts:** hand-authored inline SVG in `SellerDashboard.tsx` (revenue area line + donut).
- **Product/store imagery:** represented with CSS gradients (no real images) — replace with
  real media when available.

---

## 7. MOCKED / NEEDS WIRING

Everything below is fake/static and must be connected to real data & endpoints:

| Where | What's mocked | Needs |
|---|---|---|
| `data/landing.ts` | `heroStores`, `stats`, `testimonials`, `buyerPoints`, `sellerPoints`, `orderStages`, `buyerSteps`, `sellerSteps`, `categories`, `features` | Real API/CMS data |
| `components/AuthModal.tsx` → `submit()` | Fake 1.5s `setTimeout`, then shows success | Real login/register API call; map server validation errors onto `errors` |
| `components/AuthModal.tsx` → "Continue with Google" | No-op `onClick` | Redirect to `GET {API}/api/auth/login/google` |
| `components/AuthModal.tsx` | Client-only validation (`validate()`), password strength (`strengthScore()`) | Keep, but reconcile with server rules |
| `components/Footer.tsx` → newsletter form | Sets local `done=true`, never sends | Real newsletter subscribe endpoint |
| `components/SellerDashboard.tsx` | Hardcoded KPIs ($48,920 / 1,284 / 4.9), static SVG charts | Real dashboard metrics |
| `components/ForBuyers.tsx` / `ForSellers.tsx` | Static product/order mock cards | Real product & order data (or leave as decorative) |
| Nav / mobile menu, anchor links (`#features`, …) | In-page scroll anchors only | Real routes if sections move to pages |
| Auth success copy ("Pending review", etc.) | Static strings | Confirm against real flow |

The auth UI is a **modal**, not a route. It opens via `useAuthModal().openAuth(mode, role)`
from Nav, Hero, ForBuyers, ForSellers, and FinalCTA.

---

## 8. Design tokens

**Brand / accent**
- Violet `#8b5cf6`, Indigo `#6366f1`, Violet-300 `#a78bfa`, Cyan `#22d3ee`
- Coral gradient: `#ff8a4c` → `#ff4d6d`; pink `#ff6b81`, rose `#ff5e6c`; amber `#ffb24d`
- Link/eyebrow violet `#6d5efc`; dashboard blue `#6d8cff`
- Hero headline gradient: `linear-gradient(108deg, #a78bfa 0%, #ff6b81 52%, #ffb24d 100%)`

**Status**
- Delivered/green `#6ee7a0`, Shipped/blue `#6d8cff`, Packing/amber `#ffb24d`

**Surfaces (dark)**
- Page `#0a0a12`, alt dark `#0b0b15` / `#08080e`, dashboard `#16141f`→`#100e18`
- Hairlines `rgba(255,255,255,0.08)`; glass fills `rgba(255,255,255,0.04–0.06)`

**Surfaces (light sections)**
- White `#ffffff`, off-white `#f7f7fb` / `#faf9fe` / `#f7f6fe`, card border `#ecebf3` / `#e9e8f2`
- Ink `#15131f`, body `#5b5870`, muted `#9b97ad`

**Password-strength scale:** `#ff5d7a #ff9a4c #ffd23d #8be36b #4ade80`

**Typography**
- Display: **Outfit** 600/700 (headings, numbers); body: **Plus Jakarta Sans** 400–600
- Hero H1 `clamp(40px,6.2vw,70px)`, letter-spacing `-0.035em`, line-height `1.02`
- Section H2 `clamp(28–30px, 4–4.4vw, 44–48px)`, letter-spacing `-0.03em`
- Eyebrow labels 13px/700, letter-spacing `0.12em`, uppercase
- Body 14–17px, line-height ~1.55–1.6

**Radii:** chips/pills `999px`; buttons `11–14px`; cards `18–24px`; modal `26px`; inputs `12px`

**Shadows (representative)**
- Primary button: `0 14px 36px -10px rgba(255,77,109,0.7)`
- Card hover: `0 22px 46px -20px rgba(99,102,241,0.32)`
- Modal: `0 40px 100px -30px rgba(124,58,237,0.5)`

**Spacing:** section padding `clamp(48–64px, 6–9vw, 80–120px)`; max content width `1100–1200px`

**Keyframes (in `index.css`):** `spin`, `flow`, `hubPing`, `islandFloat`, `marquee`,
`authFade`, `drawLine`, `glowPulse`, `bobA/B/C` (bob* are legacy/unused — safe to drop).

**Breakpoints:** `940px` (collapse 2-col grids → 1-col, show mobile menu), `560px`
(stack CTA rows, single-column name fields).

---

## 9. Entry points / how it renders

1. `index.html` mounts `#root` and loads `src/main.tsx`.
2. `main.tsx` → `createRoot(...).render(<App/>)`.
3. `App.tsx` → `<AuthModalProvider>` (global auth modal) wrapping `<BrowserRouter>` with one
   route `"/"` → `<LandingPage>`.
4. `LandingPage.tsx` attaches `useLandingMotion(rootRef)` (reveal/count-up/parallax) and renders
   the sections top to bottom: Nav → Hero (with `MarketplaceRadar`) → TrustStrip → Features →
   ForBuyers → ForSellers → SellerDashboard → HowItWorks → CategoriesMarquee → Testimonials →
   FinalCTA → Footer.
5. The **auth screens** are the single `<AuthModal>` rendered by `AuthModalProvider`, opened
   from any CTA via `useAuthModal().openAuth('login'|'register', 'buyer'|'seller')`. There is
   no `/login` route in the source; add one only if you want dedicated pages.

---

## 10. Notes for the implementing engineer

- `useLandingMotion.ts` is a faithful 1:1 of the source's imperative `querySelector`-driven
  reveal. In a greenfield build prefer an `IntersectionObserver` hook + a `<Reveal>` wrapper.
- `Hoverable.tsx` exists purely to mirror the source's inline `style-hover`/`style-focus`. If
  you migrate to Tailwind/CSS classes you can delete it and use `:hover`/`:focus` utilities.
- All animation respects `prefers-reduced-motion` (handled in `index.css` + the JS effects).
